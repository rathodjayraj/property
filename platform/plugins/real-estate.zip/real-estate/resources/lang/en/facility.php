<?php

return [
    'name'   => 'Facilities',
    'create' => 'New facility',
    'edit'   => 'Edit facility',
];
