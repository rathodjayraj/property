<?php

return [
    'name'   => 'Investors',
    'create' => 'New investor',
    'edit'   => 'Edit investor',
];
