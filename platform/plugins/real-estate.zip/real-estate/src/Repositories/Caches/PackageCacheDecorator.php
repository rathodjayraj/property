<?php

namespace Botble\RealEstate\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\RealEstate\Repositories\Interfaces\PackageInterface;

class PackageCacheDecorator extends CacheAbstractDecorator implements PackageInterface
{

}
