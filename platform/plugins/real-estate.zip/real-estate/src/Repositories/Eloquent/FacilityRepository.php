<?php

namespace Botble\RealEstate\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\RealEstate\Repositories\Interfaces\FacilityInterface;

class FacilityRepository extends RepositoriesAbstract implements FacilityInterface
{
}
