<?php

namespace Botble\RealEstate\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\RealEstate\Repositories\Interfaces\RequirementInterface;

class RequirementRepository extends RepositoriesAbstract implements RequirementInterface
{
}
