<?php

namespace Botble\RealEstate\Repositories\Eloquent;

use Botble\RealEstate\Repositories\Interfaces\FeatureInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class FeatureRepository extends RepositoriesAbstract implements FeatureInterface
{
}
