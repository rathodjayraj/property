<?php

namespace Botble\RealEstate\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\RealEstate\Repositories\Interfaces\TransactionInterface;

class TransactionRepository extends RepositoriesAbstract implements TransactionInterface
{

}
